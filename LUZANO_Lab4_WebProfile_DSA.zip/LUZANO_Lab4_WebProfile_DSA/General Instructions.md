## General Instructions
```bash
pip install flask
python app.py
# open http://127.0.0.1:5000/
